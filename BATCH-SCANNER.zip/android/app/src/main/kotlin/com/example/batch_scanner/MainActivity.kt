package com.example.batch_scanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
