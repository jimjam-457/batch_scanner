import 'package:flutter/material.dart';
import 'screens/scanner_screen.dart';

void main() {
  runApp(const BatchScannerApp());
}

class BatchScannerApp extends StatelessWidget {
  const BatchScannerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Batch Scanner',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const ScannerScreen(),
    );
  }
}
