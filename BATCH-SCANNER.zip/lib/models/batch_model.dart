class BatchModel {
  String batchNo;
  String mfgDate;
  String expDate;

  BatchModel({
    required this.batchNo,
    required this.mfgDate,
    required this.expDate,
  });
}
