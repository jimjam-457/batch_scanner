import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

import '../models/batch_model.dart';
import '../utils/excel_export.dart';

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key});

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  final List<BatchModel> batches = [];
  final ImagePicker picker = ImagePicker();

  Future<void> pickImage() async {
    final XFile? image = await picker.pickImage(source: ImageSource.camera);
    if (image == null) return;

    await extractText(File(image.path));
  }

  Future<void> extractText(File file) async {
    final InputImage inputImage = InputImage.fromFile(file);
    final TextRecognizer textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);
    final RecognizedText recognizedText = await textRecognizer.processImage(inputImage);

    String fullText = recognizedText.text;

    /// REGEX patterns (based on your sample images)
    RegExp batchReg = RegExp(r'Batch\s*No[:\-]?\s*([A-Z0-9]+)', caseSensitive: false);
    RegExp mfgReg = RegExp(r'MFG\.?\s*Date[:\-]?\s*([\d\/\-\.]+)', caseSensitive: false);
    RegExp expReg = RegExp(r'EXP\.?\s*Date[:\-]?\s*([\d\/\-\.]+)', caseSensitive: false);

    String batch = batchReg.firstMatch(fullText)?.group(1) ?? '';
    String mfg = mfgReg.firstMatch(fullText)?.group(1) ?? '';
    String exp = expReg.firstMatch(fullText)?.group(1) ?? '';

    setState(() {
      batches.add(BatchModel(batchNo: batch, mfgDate: mfg, expDate: exp));
    });

    textRecognizer.close();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Batch Scanner'),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: () => ExcelExport.export(batches),
          )
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: pickImage,
        child: const Icon(Icons.camera_alt),
      ),
      body: SingleChildScrollView(
        child: DataTable(
          columns: const [
            DataColumn(label: Text('Batch No')),
            DataColumn(label: Text('MFG Date')),
            DataColumn(label: Text('EXP Date')),
          ],
          rows: batches.map((b) {
            return DataRow(cells: [
              editableCell(b.batchNo, (v) => b.batchNo = v),
              editableCell(b.mfgDate, (v) => b.mfgDate = v),
              editableCell(b.expDate, (v) => b.expDate = v),
            ]);
          }).toList(),
        ),
      ),
    );
  }

  DataCell editableCell(String value, Function(String) onChanged) {
    return DataCell(
      TextFormField(
        initialValue: value,
        decoration: const InputDecoration(border: InputBorder.none),
        onChanged: onChanged,
      ),
    );
  }
}