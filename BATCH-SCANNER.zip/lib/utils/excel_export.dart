import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';

import '../models/batch_model.dart';

class ExcelExport {
  static Future<void> export(List<BatchModel> data) async {
    final excel = Excel.createExcel();
    final sheet = excel['Batch Data'];

    sheet.appendRow(['Batch No', 'MFG Date', 'EXP Date']);

    for (var b in data) {
      sheet.appendRow([b.batchNo, b.mfgDate, b.expDate]);
    }

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/batch_data.xlsx');

    file.writeAsBytesSync(excel.encode()!);
  }
}
